# include "iGraphics.h"
#include"ninja.h"


//void gunmovement(){

	//if(gunx1<=200){
		//gunx1=gunx1-20;}
	//if(gunx1=0)
	//{
		//gunx1=200;
	//}

	//if(guny1>=100)
		//guny1=guny1-20;
	//if(guny1<=0)
		//guny1=200;


/*
	function iDraw() is called again and again by the system.
*/
void iDraw()
{
	//place your drawing codes here
	//gunmovement();
	iClear();
	if(p==1){
	iShowImage(0, 0, 400, 400, image1);
	iSetColor(0,0,0);
	iFilledRectangle(70,320,38,30);
	iSetColor(255,0,0);
	iText(75,335,"MENU");
	iSetColor(0,255,0);
	iFilledRectangle(50,260,80,20);
	iSetColor(255,0,0);
	iText(55,270,"Start Game");
	iSetColor(0,255,0);
	iFilledRectangle(50,220,80,20);
	iSetColor(255,0,0);
	iText(55,230,"Intructions");
	iSetColor(0,255,0);
	iFilledRectangle(50,180,80,20);
	iSetColor(255,0,0);
	iText(55,190,"High Score");
	iSetColor(0,255,0);
	iFilledRectangle(50,140,80,20);
	iSetColor(255,0,0);
	iText(55,150,"Credits");
	iSetColor(0,255,0);
	iFilledRectangle(50,100,80,20);
	iSetColor(255,0,0);
	iText(55,110,"Exit");
	//iSetColor(255,0,0);
	//iFilledRectangle(300,300,500,200);
  
	/*Drawing pointer*/

    iSetColor(255,0,0);
	iLine(cursorMX,cursorMY,cursorMX,cursorMY+10);
	iLine(cursorMX,cursorMY,cursorMX,cursorMY-10);
	iLine(cursorMX,cursorMY,cursorMX+10,cursorMY);
	iLine(cursorMX,cursorMY,cursorMX-10,cursorMY);}
	
	if(p==2){                                   //Background
		iShowImage(0, 0, 400, 400, image2);
		iSetColor(255,0,0);
		if(lflag<130){
			iShowImage(nx, ny, nx1,ny1, ninja);
		}
		if((nx+50)==bulletx1) {
		lflag++;
	    }
		
		iShowImage(cx1, cy1, 20,15, coin);
		if((nx<cx1 && nx+nx1>cx1) && (ny<cy1 && ny+ny1>cy1)){
			
			}
		iShowImage(164, 156, 21,16, coin);
		iShowImage(226, 183, 22,17, coin);
		iShowImage(296, 198, 23,18, coin);
		iShowImage(361, 234, 24,19, coin);
		iShowImage(346, ny, 45,80, enemy);
	    iFilledCircle(bulletx1,bullety1,5);

		//gunmovement();
	}
		
	

	if(p==4){                                //Credit
		iShowImage(0, 0, 400, 400, image3);
		iSetColor(255,255,255);
	iFilledRectangle(50,180,60,30);
	iSetColor(0,0,0);
	iText(55,200,"18.01.04.054");
	iSetColor(0,0,0);
	iText(55,190,"Aysha Shiddika ");
	iSetColor(255,255,255);
	iFilledRectangle(150,180,60,30);
	iSetColor(0,0,0);
	iText(155,200,"18.01.04.055");
	iSetColor(0,0,0);
	iText(155,190,"Umma Rumman ");
	iSetColor(255,255,255);
	iFilledRectangle(250,180,60,30);
	iSetColor(0,0,0);
	iText(255,200,"18.01.04.057");
	iSetColor(0,0,0);
	iText(255,190,"Tahrima Akter ");

		
	}
	if(p==3){                                //Instruction
		iShowImage(0, 0, 400, 400, image5);
		iSetColor(255,255,255);
		iText(160,280," INSTRUCTIONS");
		iText(50,232," I1 : press r  for right move  ");
		iText(50,215," I2 : press l arrow  for left  move ");
		iText(50,198," I3 : press backspace  for back ");
		iText(50,181," I4 : press s for fight");
	}
	if(p==5){                                //HighScore
		iShowImage(0,0,400,400,image4);
		iSetColor(0,0,0);
		iFilledRectangle(160,320,100,30);
		iSetColor(255,0,255);
		iText(170,332,"HIGH SCORE");
		
	}


}

/*
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//place your codes here
	dragMX = mx;
	dragMY = my;
}


/*
	function iPassiveMouse() is called when the user moves the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iPassiveMouse(int mx, int my)
{
    cursorMX = mx;
    cursorMY = my;
	//place your codes here
}

/*
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)
{    
	printf("x-- %d   y--%d",mx,my);



	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here
		if((mx>50 && mx<50+80 ) && (my >260 && my<260+20))
		p=2;
	}

	//else if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	
		if((mx>50 && mx<129) && (my >100 && my<100+20))
	
		{

	exit(0);

	}
		if((mx>50 && mx<50+80) && (my>140 && my<140+20))
		{ p=4; }
		if((mx>50 && mx<50+80) && (my>220 && my<220+20))
		{ p=3; }
		if((mx>50 && mx<50+80) && (my>180 && my<180+20))
		{ p=5;}

			
}

/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed.
*/
void iKeyboard(unsigned char key)
{
	if(key == 'x')
	{
		//do something with 'x'
		exit(0);
	}

	if(key == '\b')
	{
		//do something with 'x'
		p=1;
	}
	
	//place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
*/
void iSpecialKeyboard(unsigned char key)
{

	if(key == GLUT_KEY_UP)
	{
		ny+=10;
	}
	if(key == GLUT_KEY_DOWN)
	{
		ny-=10;
	}
	if(key == GLUT_KEY_RIGHT)
	{
		nx+=10;
	}
	if(key == GLUT_KEY_LEFT)
	{
		nx-=12;
	}


	//place your codes for other keys here
}
void bulletChange(){
	bulletx1 -= dx;
	
	if(bulletx1 < 50){
		bulletx1=346;
		bullety1=ny+50;}
	//if((nx>gunx1 && nx+nx1<gunx1 ) && (ny>guny1 && ny+ny1<guny1 )) {
		//cflag++;//
	


}
int main()
{
	//place your own initialization codes here.

	cflag=0;
	dx=5;
	dy=7;
	bulletx1=390;
	bullety1=ny;

	bullettimer= iSetTimer(40, bulletChange);

	iInitialize(400, 400, "Slaying Ninja.");
	image1 = iLoadImage("images\\11862.jpg");
	image2 = iLoadImage("images\\backgr.jpg");
	image3 = iLoadImage("images\\picture3.jpg");
	image5 = iLoadImage("images\\11900.jpg");
	image4 = iLoadImage("images\\11861.jpg");
	ninja= iLoadImage("images\\ninja1.png");
	coin=iLoadImage("images\\download.png");
	enemy=iLoadImage("images\\enemy (2).png");
	iStart();
	
	return 0;
}
